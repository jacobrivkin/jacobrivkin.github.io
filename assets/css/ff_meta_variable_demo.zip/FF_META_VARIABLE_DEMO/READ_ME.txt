This .zip file contains the following FF Meta Variable Demo font software:
 - MetaVariableDemo-Italic.ttf
 - MetaVariableDemo-Roman.ttf
 - MetaVariableDemo-Set.ttf
(Italic has an Italic axis, Roman has a weight axis, and Set contains both weight and italic axes)

The FF Meta Variable Demo font software is for demonstration purposes and is provided "as is" without warranties of any kind. Your rights to use this font software expire on December 31, 2019.

These demo fonts are licensed for installation and use on one (1) workstation. For web fonts, please refer to the link to the hosted web fonts.

This font software is the property of Monotype GmbH, or one of its affiliated entities ("Monotype") and its use by you is covered under the terms of a license agreement. This software is a valuable asset of Monotype. Your use of this software is limited by the terms of the actual license agreement you have entered into with Monotype. You may not copy or distribute this software.

If you have any questions concerning your rights you should review the license agreement you received with the software. You can learn more about Monotype by clicking here: www.monotype.com.

About the FF Meta typefaces
German type designer Erik Spiekermann, created this sans FontFont between 1991 and 2010. The family has 28 weights, ranging from Hairline to Black in Condensed and Normal (including italics) and is ideally suited for advertising and packaging, book text, editorial and publishing, logo, branding and creative industries, small text as well as web and screen design. Starting with these fonts as the basis, Marianna Paszkowska of Monotype produced this variable font in 2018 to encompass both weight and italic axes.

